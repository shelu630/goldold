import { auth } from './firebase_config.js';
import {
  RecaptchaVerifier,
  signInWithPhoneNumber
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

let confirmationResult;

window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
  'size': 'normal',
  'callback': function (response) {
    console.log("reCAPTCHA Solved ✅");
  }
});
recaptchaVerifier.render();

window.sendOTP = function () {
  const phoneNumber = document.getElementById("phoneNumber").value;
  signInWithPhoneNumber(auth, phoneNumber, window.recaptchaVerifier)
    .then((result) => {
      confirmationResult = result;
      document.getElementById("result").innerText = "OTP Sent ✅";
    })
    .catch((error) => {
      console.error(error);
      alert("Failed to send OTP ❌");
    });
};

window.verifyOTP = function () {
  const otp = document.getElementById("otp").value;
  confirmationResult.confirm(otp).then((result) => {
    const user = result.user;
    document.getElementById("result").innerText = "Login Success 🎉";
  }).catch((error) => {
    alert("Incorrect OTP ❌");
  });
};
